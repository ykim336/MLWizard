from mlwizards import extract_text_from_pdf, preprocess_text

api_key = "sk-proj-7BSOvdBQ6iu7kECXamQhT3BlbkFJZrM8cXNmYH56T7J1sU7L"
bot = ChatBot(api_key=api_key, model="gpt-3.5-turbo")


