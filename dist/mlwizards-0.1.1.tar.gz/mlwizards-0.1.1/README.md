# MLWizard
A simple python library that makes the process of making a chatbot easier with finetuning and internet capabilities.
